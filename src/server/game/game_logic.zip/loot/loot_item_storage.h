#pragma once


#include <unordered_map>
#include "interface_header/base/IDataAgentModule.h"

namespace zq {

class Item;
class Player;
struct Loot;
struct LootItem;

namespace boost
{
    class shared_mutex;
}

struct StoredLootItem
{
    explicit StoredLootItem(LootItem const& lootItem);

    uint32 ItemId;
    uint32 Count;
    bool FollowRules;
    bool FFA;
    bool Blocked;
    bool Counted;
    bool UnderThreshold;
    bool NeedsQuest;
    int32 RandomPropertyId;
    uint32 RandomSuffix;
};

class StoredLootContainer
{
public:
    typedef std::unordered_multimap<uint32 /*itemId*/, StoredLootItem> StoredLootItemContainer;

    explicit StoredLootContainer(uint32 containerId) : _containerId(containerId), _money(0) { }

    void AddLootItem(LootItem const& lootItem/*, SQLTransaction& trans*/);
    void AddMoney(uint32 money/*, SQLTransaction& trans*/);

    void RemoveMoney();
    void RemoveItem(uint32 itemId, uint32 count);

    uint32 GetContainer() const { return _containerId; }
    uint32 GetMoney() const { return _money; }
    StoredLootItemContainer const& GetLootItems() const { return _lootItems; }

private:
    StoredLootItemContainer _lootItems;
    uint32 const _containerId;
    uint32 _money;
};

class LootItemStorage
{
public:
    static LootItemStorage* instance();

    void LoadStorageFromDB();
    bool LoadStoredLoot(Item* item, Player* player);
    void RemoveStoredMoneyForContainer(uint32 containerId);
    void RemoveStoredLootForContainer(uint32 containerId);
    void RemoveStoredLootItemForContainer(uint32 containerId, uint32 itemId, uint32 count);
    void AddNewStoredLoot(Loot* loot, Player* player);

private:
    LootItemStorage() { }
    ~LootItemStorage() { }
};

#define sLootItemStorage LootItemStorage::instance()

}
