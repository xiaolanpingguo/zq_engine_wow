//#include "../groups/group.h"
//#include "group_reference.h"
//
//
//namespace zq{
//
//void GroupReference::targetObjectBuildLink()
//{
//    // called from link()
//    getTarget()->LinkMember(this);
//}
//
//void GroupReference::targetObjectDestroyLink()
//{
//    // called from unlink()
//    //getTarget()->DelinkMember(this);
//}
//
//void GroupReference::sourceObjectDestroyLink()
//{
//    // called from invalidate()
//    //getTarget()->DelinkMember(this);
//}
//
//}
