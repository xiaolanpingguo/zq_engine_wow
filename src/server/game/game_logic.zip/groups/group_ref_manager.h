#pragma once

#include "group_reference.h"
#include "baselib/base_code/ref_manager.hpp"

namespace zq{

class Group;
class Player;
class GroupRefManager : public RefManager<Group, Player>
{
public:
    GroupReference* getFirst() { return ((GroupReference*)RefManager<Group, Player>::getFirst()); }
    GroupReference const* getFirst() const { return ((GroupReference const*)RefManager<Group, Player>::getFirst()); }
};

}
