//#pragma once
//
//
//#include "../object/object_guid.h"
//#include <unordered_map>
//
//
//namespace zq{
//
//class Corpse;
//class Creature;
//class DynamicObject;
//class GameObject;
//class Map;
//class Object;
//class Pet;
//class Player;
//class Transport;
//class Unit;
//class WorldObject;
//
//namespace boost
//{
//    class shared_mutex;
//}
//
//template <class T>
//class  HashMapHolder
//{
//    //Non instanceable only static
//    HashMapHolder() { }
//
//public:
//
//    typedef std::unordered_map<ObjectGuid, T*> MapType;
//
//    static void Insert(T* o);
//
//    static void Remove(T* o);
//
//    static T* Find(ObjectGuid guid);
//
//    static MapType& GetContainer();
//
//    static boost::shared_mutex* GetLock();
//};
//
//namespace ObjectAccessor
//{
//    // these functions return objects only if in map of specified object
//     WorldObject* GetWorldObject(WorldObject const&, ObjectGuid const&);
//     Object* GetObjectByTypeMask(WorldObject const&, ObjectGuid const&, uint32 typemask);
//     Corpse* GetCorpse(WorldObject const& u, ObjectGuid const& guid);
//     GameObject* GetGameObject(WorldObject const& u, ObjectGuid const& guid);
//     Transport* GetTransport(WorldObject const& u, ObjectGuid const& guid);
//     DynamicObject* GetDynamicObject(WorldObject const& u, ObjectGuid const& guid);
//     Unit* GetUnit(WorldObject const&, ObjectGuid const& guid);
//     Creature* GetCreature(WorldObject const& u, ObjectGuid const& guid);
//     Pet* GetPet(WorldObject const&, ObjectGuid const& guid);
//     Player* GetPlayer(Map const*, ObjectGuid const& guid);
//     Player* GetPlayer(WorldObject const&, ObjectGuid const& guid);
//     Creature* GetCreatureOrPetOrVehicle(WorldObject const&, ObjectGuid const&);
//
//    // these functions return objects if found in whole world
//    // ACCESS LIKE THAT IS NOT THREAD SAFE
//     Player* FindPlayer(ObjectGuid const&);
//     Player* FindPlayerByName(std::string const& name);
//     Player* FindPlayerByLowGUID(ObjectGuid::LowType lowguid);
//
//    // this returns Player even if he is not in world, for example teleporting
//     Player* FindConnectedPlayer(ObjectGuid const&);
//     Player* FindConnectedPlayerByName(std::string const& name);
//
//    // when using this, you must use the hashmapholder's lock
//     HashMapHolder<Player>::MapType const& GetPlayers();
//
//    template<class T>
//    void AddObject(T* object)
//    {
//        HashMapHolder<T>::Insert(object);
//    }
//
//    template<class T>
//    void RemoveObject(T* object)
//    {
//        HashMapHolder<T>::Remove(object);
//    }
//
//    template<>
//    void AddObject(Player* player);
//
//    template<>
//    void RemoveObject(Player* player);
//
//     void SaveAllPlayers();
//};
//
//}
