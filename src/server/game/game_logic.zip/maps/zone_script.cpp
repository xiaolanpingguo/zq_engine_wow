#include "zone_script.h"
#include "../entities/creature/creature.h"


namespace zq{

uint32 ZoneScript::GetCreatureEntry(ObjectGuid::LowType /*guidLow*/, CreatureData const* data)
{
    return data->id;
}

}
